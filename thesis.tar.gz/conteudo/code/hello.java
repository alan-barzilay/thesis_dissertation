class HelloWorld {
    public static void main(String[] args) {
        System.out.println("Hello, World!");
        int a, b;
        
        a = 3;
        b = 4;
        int c = a + b;
        
        // Random comments for illustrative purposes
        // private static int extracted(int a, int b) {
        // int c = a + b;
        // return c;
        // }
    }
}
